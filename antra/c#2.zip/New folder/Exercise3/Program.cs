﻿using System;

namespace Exercise3
{
    class Program
    {
        static void Main(string[] args)
        {
            Solution sl = new Solution();
            sl.userInput();
        }
    }
}
