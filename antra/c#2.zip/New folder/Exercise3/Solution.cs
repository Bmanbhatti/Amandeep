﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise3
{
    class Solution
    {
        public void userInput()
        {
            Console.Write("enter value of a ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.Write("enter value of b ");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.Write($"Numbers of perfect squares between{a} and {b} are : { solution(a, b)} ");
           

        }
        public int solution(int a, int b)
        {

            // Initialize result
            int cnt = 0;

            // Traverse through all numbers
            for (int i = a; i <= b; i++)

                // Check if current number
                // 'i' is perfect square
                for (int j = 1; j * j <= i; j++)
                    if (j * j == i)
                        cnt++;
            return cnt;
           
        }
    }
}
