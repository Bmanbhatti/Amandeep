﻿using System;

namespace Expercise4
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] ar = new int[3,3]{ {1,2,3 },{4,5,6 },{7,8,9 } };
            Console.WriteLine("Hello World!");
        }
    }
}
