﻿using System;

namespace Exercise2
{
    class Program
    {
        static void Main(string[] args)
        {
            Solution sl = new Solution();
            sl.userInput();
           
        }
    }
}
