﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise2
{
    class Solution
    {
        int length =0;
        int val = 0;
        
        public void userInput()
        {
            Console.Write("enter array length: ");
            length = Convert.ToInt32(Console.ReadLine());
            int[] ar = new int[length];
            for (int i = 0; i < length; i++)
            { 
             Console.Write("enter value: ");
                val = Convert.ToInt32(Console.ReadLine());
                ar[i] = val;

            }
            Console.Write("Max repeated value: " + solution(ar));
            
           
        }
        public int solution(int[] arr)
        {
            Array.Sort(arr);
            int n = length;
            // find the max frequency using
          
            int max_count = 1, res = arr[0];
            int curr_count = 1;

            for (int i = 1; i < n; i++)
            {
                if (arr[i] == arr[i - 1])
                    curr_count++;
                else
                {
                    if (curr_count > max_count)
                    {
                        max_count = curr_count;
                        res = arr[i - 1];
                    }
                    curr_count = 1;
                }
            }

            // If last element is most frequent
            if (curr_count > max_count)
            {
                max_count = curr_count;
                res = arr[n - 1];
            }

            return res;
        }


    }
}
