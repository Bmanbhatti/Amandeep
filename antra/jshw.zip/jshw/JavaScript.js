﻿let salaries = {
    John: 100,
    Ann: 160,
    Pete: 130,
};

const sum = Object.values(salaries).reduce((acc, val) => acc + val); 

console.log(sum)

// 2

let menu = {
    width: 200,
    height: 360,
    title: "My Menu",
};

const multiplyNumeric = (menu) => {
    let obj = {};

    const outPut = Object.values(menu).map((i) => {
        if (typeof i === "number") {
            return 2 * i;
        } else {
            return i;
        }
    });
    for (let i = 0; i < outPut.length; i++) {
        obj[Object.keys(menu)[i]] = outPut[i];
    }
    return obj;
};
console.log(multiplyNumeric(menu));

// 3

const checkEmailId = (str) => {
    if (str.includes("@") && str.includes(".")) {
        if (str.indexOf("@") < str.indexOf(".")) {
            if (str.indexOf("@") + 1 !== str.indexOf(".")) {
                return true;
            }
        }
    }
    return false;
};

console.log(checkEmailId('@a.b'))

// 4

const truncate = (str, maxLength) => {
    let newStr;
    if (str.length > maxLength) {
        newStr = str.slice(0, maxLength - 3);
    }
    return `${newStr}...`;
};

console.log(truncate("hello friend", 10));

// 5

const arr = ["James", "Brennie"];
// add at end
arr.push("Robert");
// find middle index
const middle = arr[Math.round((arr.length - 1) / 2)];
// replace
arr.splice(arr.indexOf(middle), 1, "Calvin");
// remove first
arr.shift();
// add at beginning
arr.unshift("Rose", "Regal");

// 6

const validateCards = (cardsToValidate, bannedPrefixes) => {
    let outputObj = {
        card: cardsToValidate,
        isValid: false,
        isAllowed: true,
    };
    // isAllowed Check

    for (let i = 0; i < bannedPrefixes.length; i++) {
        if (cardsToValidate.startsWith(bannedPrefixes[i])) {
            outputObj.isAllowed = false;
        }
    }

    // isValid check
    let multipliedDigitsArray = [];
    for (let i = 0; i < cardsToValidate.length - 1; i++) {
        multipliedDigitsArray.push(parseInt(cardsToValidate[i]) * 2);
    }
    const sumOfAllDigits = multipliedDigitsArray.reduce(
        (acc, val) => acc + val
    );
    const checkDigit = sumOfAllDigits % 10;
    if (
        checkDigit ===
        parseInt(cardsToValidate.slice(cardsToValidate.length - 1))
    ) {
        outputObj.isValid = true;
    }
    return outputObj;
};

console.log(validateCards("6724843711060148", ["11", "3434", "67453", "9"]));

// 7

let pattern = /^[a-e+_0-4]+@hackerrank.com\s*$/;
// TODO: underscore in between alphabets and numbers
console.log(pattern.test('abcde12@hackerrank.com'))