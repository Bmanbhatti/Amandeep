﻿using System;

namespace Exercise4
{
    class Program
    {
        static void Main(string[] args)
        {
            ArmStrong arm = new ArmStrong();
            Console.Write("Enter first number: ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second number: ");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.Write("Answer is: ");
            arm.findall(a, b);
        }
    }
}
