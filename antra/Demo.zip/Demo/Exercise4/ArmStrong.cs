﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise4
{
    class ArmStrong
    {
        public void findall(int a, int b)
        {

            for (int i = a + 1; i < b; ++i)
            {

                // number of digits calculation
                int x = i;
                int n = 0;
                while (x != 0)
                {
                    x /= 10;
                    ++n;
                }

                // compute sum of nth power of
                // its digits
                int pow_sum = 0;
                x = i;
                while (x != 0)
                {
                    int digit = x % 10;
                    pow_sum += (int)Math.Pow(digit, n);
                    x /= 10;
                }

                // checks if number i is equal
                // to the sum of nth power of
                // its digits
                if (pow_sum == i)
                    Console.Write(i + " ");

            }
        }
    }
}
