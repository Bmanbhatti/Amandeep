﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise2
{
    class Arithmetic
    {
        string choice;
        int a, b;
        public void askforvalues()
        {
            Console.Write("Enter your Choice(addition,substraction,multipication or division): ");
            choice = Console.ReadLine();
            Console.Write("Enter first number: ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second number: ");
            b = Convert.ToInt32(Console.ReadLine());
            Console.Write("Answer is: ");
            switchstate(choice, a, b);
        }
        public void switchstate( string s, int a, int b)
         {
            string str = s;
            switch (str)
            {
                case "addition":
                    addition(a, b);
                    break;
                case "substraction":
                    subtraction(a, b);
                    break;
                case "multipication":
                    multipication(a, b);
                    break;
                case "division":
                    division(a, b);
                    break;
            }
         }

        public void addition(int a, int b)
        {
            Console.WriteLine(a+b);
        }
        public void subtraction(int a, int b)
        {
            Console.WriteLine(a - b);
        }
        public void multipication(int a, int b)
        {
            Console.WriteLine(a * b);
        }
        public void division(int a, int b)
        {
            Console.WriteLine(a / b);
        }

    }
}
