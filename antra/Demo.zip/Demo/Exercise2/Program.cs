﻿using System;

namespace Exercise2
{
    class Program
    {
        static void Main(string[] args)
        {
            Arithmetic ar = new Arithmetic();
            ar.askforvalues();
        }
    }
}
