﻿using System;

namespace Exercise3
{
    class Program
    {
        static void Main(string[] args)
        {
            Reverse reverse = new Reverse();
            reverse.reverseString();

        }
    }
}
