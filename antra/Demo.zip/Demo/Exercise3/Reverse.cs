﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise3
{
    class Reverse
    {
        String  str = "program allows user to enter his own string";
        String rev = "";
        public void reverseString()
        {
            Stack<string> myStack = new Stack<string>();
            for (int i = 0; i < str.Length; i++)
            {
                myStack.Push(str.Substring(i,1));
            }
            for (int i = 0; i < str.Length; i++)
            {
                rev += myStack.Pop(); 
            }
            Console.WriteLine(rev);

        }

    }
}
