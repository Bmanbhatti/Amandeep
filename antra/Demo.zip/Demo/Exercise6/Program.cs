﻿using System;

namespace Exercise6
{
    class Program
    {
        static void Main(string[] args)
        {
            Dim dim = new Dim();
            dim.and();
        }
    }
}
