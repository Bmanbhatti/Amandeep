﻿using System;

namespace DemoTask
{
    class Program
    {
        static void Main(string[] args)
        {
            Student stu = new Student();
            stu.GetData();
            stu.DisplayData();
            Console.ReadKey();
        }
    }
}
