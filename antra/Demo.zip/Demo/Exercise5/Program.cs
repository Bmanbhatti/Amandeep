﻿using System;

namespace Exercise5
{
    class Program
    {
        static void Main(string[] args)
        {
            printTri printTri = new printTri();
            printTri.print();
        }
    }
}
