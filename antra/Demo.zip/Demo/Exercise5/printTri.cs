﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise5
{
    class printTri
    {

        public void print()
        {

            int p, lastInt = 0, input;
            Console.WriteLine("Enter the Number of Rows : ");
            input = int.Parse(Console.ReadLine());
            Console.WriteLine("Here Comes the tree.....");
            for (int i = 0; i < input; i++)
            {
                for (p = 0; p < i+1; p++)
                {
                    if (lastInt == 1)
                    {
                        Console.Write("0");
                        lastInt = 0;
                    }
                    else if (lastInt == 0)
                    {
                        Console.Write("1");
                        lastInt = 1;
                    }
                }
                Console.Write("\n");
            }
            Console.ReadLine();

        }
    }
}
