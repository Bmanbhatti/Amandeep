﻿using System;

namespace Exercise1
{
    class Program
    {
        static void Main(string[] args)
        {
            Shape1 ric = new Rectangle();
            ric.getDimentions();
            Console.WriteLine(ric.Area());
            Console.WriteLine(ric.Circumference());

            Shape1 cir = new circle();
            cir.getDimentions();
            Console.WriteLine(cir.Area());
            Console.WriteLine(cir.Circumference());
        }
    }
}
