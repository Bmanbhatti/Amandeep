﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise1
{
    abstract class Shape1
    {
        protected float R, L, B;

        //Abstract methods can have only declarations
        public abstract float Area();
        public abstract float Circumference();
        public abstract void  getDimentions();

    }

    class Rectangle : Shape1
    {
         
        public override void getDimentions()
        {
            Console.Write(" Enter Length of Rectangle: ");
            L = Convert.ToInt32(Console.ReadLine());
            Console.Write(" Enter width of Rectangle: ");
            B = Convert.ToInt32(Console.ReadLine());
        }
        public override float Area()
        {
            return L * B;
           
        }

        public override float Circumference()
        {
            return 2*(L + B);
        }
    }
    class circle : Shape1
    {
        float pie = Convert.ToSingle(3.14);
        
        public override void getDimentions()
        {
            Console.Write(" Enter Radious of Cirlce: ");
             R = (float)Convert.ToDouble(Console.ReadLine());

        
        }
        public override float Area()
        {
            return pie*R*R;

        }

        public override float Circumference()
        {
            return 2 * pie * R;
        }
    }
}
