﻿using System;

namespace Exercise4
{
    class StudentAndTeacherTest
    {
        static void Main(string[] args)
        {
            Execute ex = new Execute();
            ex.run();
        }
    }
}
