﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise4
{
    class Execute
    {
        public void run()
        {
            Student stu = new Student();
            Console.WriteLine("Hello");

            Teacher teach = new Teacher();
            Console.WriteLine("Hello");

            stu.SetAge(20);
            teach.SetAge(30);
            stu.ShowAge();
            teach.Explain();




        }

    }
}
