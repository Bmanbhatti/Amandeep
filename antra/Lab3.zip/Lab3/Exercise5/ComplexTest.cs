﻿using System;

namespace Exercise5
{
    class ComplexTest
    {
        static void Main(string[] args)
        {
            ComplexNumber number = new ComplexNumber(5, 2);
            Console.WriteLine("Number is: " + number.toString());

            number.SetImaginary(-3);
            Console.WriteLine("Number is: " + number.toString());

            Console.Write("Magnitude is: ");
            Console.WriteLine(number.GetMagnitude());

            ComplexNumber number2 = new ComplexNumber(-1, 1);
            number.add(number2);
            Console.Write("After adding: ");
            Console.WriteLine(number.toString());


        }
    }
}
