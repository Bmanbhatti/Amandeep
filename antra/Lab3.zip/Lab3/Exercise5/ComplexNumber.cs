﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise5
{
    class ComplexNumber
    {
        private double a;
        private double b;
        public ComplexNumber(double a, double b)
        {
            this.a = a;
            this.b = b;
        }
        public double geta()
        {
            return a;

        }
        public double getb()
        {
            return b;

        }
        public String toString()
        {
            String s = $"({a}, {b})";
            return s;
        }

        public void SetImaginary(double i)
        {
            b = i;

        }
        public double GetMagnitude()
        {
            double mag = Math.Sqrt((a*a)+(b*b));
            return mag;
        }
        public void add( ComplexNumber c )
        {
            double fa = c.geta();
            double fb = c.getb();

            a = a + fa;
            b = b + fb;
        }

    }
}
