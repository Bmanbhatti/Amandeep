﻿using System;
using System.Collections.Generic;

namespace Exercise3
{
    
    class Program
    {
        static void VarTest()
        {
            var i = 43;
            var x = new[] { 1, 2, 3 };
            var s = "...This is only a test...";

            var numbers = new[] { 4, 9, 16 };
            var complex = new SortedDictionary<string, List<DateTime>>();


        }

        static void Main(string[] args)
        {

            var customers = CreateCustomers();

            Console.WriteLine("Customers:\n");
            foreach (var c in customers)
                Console.WriteLine(c);


        }
    }
}
