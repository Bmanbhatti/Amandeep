﻿function getData() {

     let p1 = fetch("https://fakerestapi.azurewebsites.net//api/v1/Users").then(function (response) {
         return response.json();

     }).then((data) => {
        
         return data;
        
     } 
     )
    
    p1.then(function (data) {
        let tbody = document.querySelector("tbody");
        tbody.innerHTML = "";
        let length = data.length;
        for (var i = 0; i < length; i++) {
            let tr = "<tr> <td>" + data[i].id + "</td> <td>" + data[i].userName + "</td> <td>" + data[i].password + "</td> </tr>"
            tbody.innerHTML += tr;
        }
    }
    ).catch(function (e) { return e })
}


